import os
import sys
import time
import json
import requests
import pandas as pd
from pathlib import Path
from datetime import datetime, timezone

# -------------------- CONFIG --------------------
API_KEY = os.getenv("HA_API_KEY", "raid3gdy6839363de5shgypd12443f3ce7wlmscqc93cd275d96gyye78d0235f3").strip()
BASE_URL = "https://hybrid-analysis.com/api/v2"  # no 'www'
HEADERS = {"api-key": API_KEY, "User-Agent": "Falcon", "Accept": "application/json"}
TIMEOUT = 30
BACKOFF_SECONDS = 3

# Input SHA lists (one header line: 'sha256', then values)
#SHA_FILES = ['agenttesla.txt','blackcat.txt','clop.txt']
#SHA_FILES ='conti.txt','lockbit.txt','lumma.txt']
#SHA_FILES ='phobos.txt','qbot.txt','redline.txt']
SHA_FILES =['a310logger.txt','AgentTesla.txt','AsyncRAT.txt']
#SHA_FILES =['Kovter.txt','DonutLoader.txt','Chaos.txt']
#SHA_FILES =['GuLoader.txt','Formbook.txt','Stealc.txt']
#SHA_FILES =['Vidar.txt','SalatStealer.txt','QuasarRAT.txt','Phorpiex.txt']
#SHA_FILES =['Black.txt','NanoCore.txt','Socks5Systemz.txt','MassLogger.txt']
#SHA_FILES =['Black Suit.txt','DoppelPaymer.txt','Akira.txt','MedusaLocker.txt']

# Output dataset files (append-only)
DISK_XLSX    = Path("disk_dataset.xlsx")
NETWORK_XLSX = Path("network_dataset.xlsx")
MEMORY_XLSX  = Path("memory_dataset.xlsx")

TEMP_JSON = Path("temp_report.json")

# -------------------- SCHEMAS (fixed columns) --------------------
DISK_COLS = [
    "sha256", "size", "type",
    "parent_sha256", "parent_size", "parent_type", "parent_imphash",
    "file_name", "file_path", "target"
]
NETWORK_COLS = [
    "sha256_sample",
    "domain_count", "domains",
    "host_count", "hosts",
    "total_network_connections",
    "target",
]
MEMORY_COLS = [
    "sha256",
    "normalized_path",
    "command_line",
    "parent_sha256",
    "total_processes",
    "created_files",
    "registry",
    "modules_count",
    "target",
]

# -------------------- HTTP helpers --------------------
def _get(url, params=None):
    r = requests.get(url, headers=HEADERS, params=params or None, timeout=TIMEOUT)
    if r.status_code == 429:
        time.sleep(BACKOFF_SECONDS)
        r = requests.get(url, headers=HEADERS, params=params or None, timeout=TIMEOUT)
    if r.status_code >= 400:
        # Show server message; the script will skip this SHA gracefully
        print(f"HTTP {r.status_code} {url}\n{r.text[:1000]}")
        return None
    return r.json()

def find_any_analysis_id(sha256: str):
    print("SHA-256:",sha256)
    data = _get(f"{BASE_URL}/search/hash", params={"hash": sha256})
    print("Found Data:",data)
    if not data or "reports" not in data or not isinstance(data["reports"], list) or not data["reports"]:
        return None, None
    # Just take the first available report
    first = data["reports"][0]
    return first.get("id"), first.get("environment_description")

def fetch_summary_json(analysis_id: str):
    js = _get(f"{BASE_URL}/report/{analysis_id}/summary")
    if not js:
        return None
    # persist as temp file (as requested)
    TEMP_JSON.write_text(json.dumps(js, indent=2, ensure_ascii=False), encoding="utf-8")
    return js

# -------------------- dataset append helpers --------------------
def append_rows_to_excel(rows_df: pd.DataFrame, xlsx_path: Path, columns: list):
    """Append rows_df to an Excel file with fixed schema columns; create if missing."""
    if rows_df.empty:
        return
    # Ensure column order and missing columns
    for c in columns:
        if c not in rows_df.columns:
            rows_df[c] = pd.NA
    rows_df = rows_df[columns]

    if xlsx_path.exists():
        try:
            existing = pd.read_excel(xlsx_path, engine="openpyxl")
        except Exception:
            existing = pd.DataFrame(columns=columns)
        combined = pd.concat([existing, rows_df], ignore_index=True)
    else:
        combined = rows_df

    combined.to_excel(xlsx_path, index=False)

# -------------------- extractors (strict to your hierarchy) --------------------
def extract_disk_rows(js: dict, target: str) -> pd.DataFrame:
    # parent fields
    for key in ["sha256", "size", "type", "imphash"]:
        if key not in js:
            return pd.DataFrame(columns=DISK_COLS)
    parent_sha256  = js["sha256"]
    parent_size    = js["size"]
    parent_type    = js["type"]
    parent_imphash = js["imphash"]

    if "extracted_files" not in js or not isinstance(js["extracted_files"], list):
        return pd.DataFrame(columns=DISK_COLS)

    rows = []
    for f in js["extracted_files"]:
        if not isinstance(f, dict):
            continue
        # required child keys per agreed schema
        for k in ["sha256", "file_size", "name", "file_path", "threat_level", "type_tags"]:
            if k not in f:
                break
        else:
            # keep only threat_level > 0
            try:
                if int(f["threat_level"]) <= 0:
                    continue
            except Exception:
                continue
            child_type = f["type_tags"][0] if isinstance(f["type_tags"], list) and f["type_tags"] else None
            rows.append({
                "sha256": f["sha256"],
                "size": f["file_size"],
                "type": child_type,
                "parent_sha256": parent_sha256,
                "parent_size": parent_size,
                "parent_type": parent_type,
                "parent_imphash": parent_imphash,
                "file_name": f["name"],
                "file_path": f["file_path"],
                "target": target,
            })
    return pd.DataFrame(rows, columns=DISK_COLS) if rows else pd.DataFrame(columns=DISK_COLS)

def _to_strings(lst, key_for_dict=None):
    out = []
    for item in (lst or []):
        if isinstance(item, dict):
            if key_for_dict and key_for_dict in item:
                out.append(str(item[key_for_dict]))
            else:
                out.append(str(item))
        else:
            out.append(str(item))
    return out

def extract_network_row(js: dict, target: str) -> pd.DataFrame:
    # required top-level keys for this row
    if "sha256" not in js:
        return pd.DataFrame(columns=NETWORK_COLS)

    sha256_sample = js["sha256"]
    total_net_conns = js.get("total_network_connections", 0)

    raw_domains = js.get("domains", [])
    raw_hosts   = js.get("hosts", [])

    domains = _to_strings(raw_domains, key_for_dict="domain")
    hosts   = _to_strings(raw_hosts, key_for_dict="ip")

    row = {
        "sha256_sample": sha256_sample,
        "domain_count": len(domains),
        "domains": ";".join(domains),
        "host_count": len(hosts),
        "hosts": ";".join(hosts),
        "total_network_connections": total_net_conns,
        "target": target,
    }
    return pd.DataFrame([row], columns=NETWORK_COLS)

def _stringify_list(lst):
    if not isinstance(lst, list):
        return ""
    return ";".join([str(x) for x in lst])

def extract_memory_rows(js: dict, target: str) -> pd.DataFrame:
    if "sha256" not in js:
        return pd.DataFrame(columns=MEMORY_COLS)
    parent_sha256 = js["sha256"]
    total_processes = js.get("total_processes", 0)

    if "processes" not in js or not isinstance(js["processes"], list):
        return pd.DataFrame(columns=MEMORY_COLS)

    rows = []
    for proc in js["processes"]:
        if not isinstance(proc, dict):
            continue
        # filter: av_matched > 0
        try:
            if int(proc.get("av_matched", 0)) <= 0:
                continue
        except Exception:
            continue
        # required fields
        for k in ["sha256", "normalized_path", "command_line"]:
            if k not in proc:
                break
        else:
            created_files_str = _stringify_list(proc.get("created_files", []))
            registry_str      = _stringify_list(proc.get("registry", []))
            modules           = proc.get("modules", [])
            modules_count     = len(modules) if isinstance(modules, list) else 0

            rows.append({
                "sha256": proc["sha256"],
                "normalized_path": proc["normalized_path"],
                "command_line": proc["command_line"],
                "parent_sha256": parent_sha256,
                "total_processes": total_processes,
                "created_files": created_files_str,
                "registry": registry_str,
                "modules_count": modules_count,
                "target": target,
            })
    return pd.DataFrame(rows, columns=MEMORY_COLS) if rows else pd.DataFrame(columns=MEMORY_COLS)

# -------------------- SHA reader --------------------
def read_sha_list(txt_path: Path):
    """
    Reads a .txt with a single column named 'sha256'.
    Accepts either CSV-style with header or simple newline list with header on first line.
    """
    if not txt_path.exists():
        print(f"Missing file: {txt_path}")
        return []
    # Try pandas (covers CSV/TSV/space); fallback to manual
    try:
        df = pd.read_csv(txt_path, engine="python")
        if "sha256" in df.columns:
            vals = [str(x).strip() for x in df["sha256"].tolist() if pd.notna(x)]
            return [v for v in vals if v and v.lower() != "sha256"]
    except Exception:
        pass
    # Fallback manual
    lines = [l.strip() for l in txt_path.read_text(encoding="utf-8", errors="ignore").splitlines()]
    lines = [l for l in lines if l and l.lower() != "sha256"]
    return lines

# -------------------- MAIN --------------------
def main():
    if not API_KEY or len(API_KEY) < 40:
        sys.exit("Set HA_API_KEY with a valid Hybrid Analysis API key.")

    for fname in SHA_FILES:
        family_path = Path(fname)
        target = family_path.stem  # "Akira", "BlackSuit", etc.
        print(f"\n=== Processing family: {target} ===")
        sha_list = read_sha_list(family_path)
        if not sha_list:
            print(f"No SHA256s found in {fname}")
            continue

        disk_rows_all = []
        net_rows_all  = []
        mem_rows_all  = []

        for idx, sha in enumerate(sha_list, 1):
            print(f"[{target}] ({idx}/{len(sha_list)}) SHA={sha[:12]}…")

            analysis_id, env_desc = find_any_analysis_id(sha)
            print("Analysis ID:",analysis_id,"\nEnv Desc:",env_desc)
            if not analysis_id:
                print("No analysis_id found; skipping.")
                continue

            js = fetch_summary_json(analysis_id)
            if not js:
                print("Summary fetch failed; skipping.")
                continue

            # Extract rows per dataset
            try:
                ddf = extract_disk_rows(js, target)
                ndf = extract_network_row(js, target)
                mdf = extract_memory_rows(js, target)
            except Exception as e:
                print(f"Extraction error: {e}")
                ddf = ndf = mdf = pd.DataFrame()

            if not ddf.empty: disk_rows_all.append(ddf)
            if not ndf.empty: net_rows_all.append(ndf)
            if not mdf.empty: mem_rows_all.append(mdf)

            # cleanup temp json for this SHA
            try:
                if TEMP_JSON.exists():
                    TEMP_JSON.unlink()
            except Exception:
                pass

            # Be nice to the API
            time.sleep(0.4)

        # Append to Excel files
        if disk_rows_all:
            append_rows_to_excel(pd.concat(disk_rows_all, ignore_index=True), DISK_XLSX, DISK_COLS)
            print(f"Appended Disk rows: {sum(len(x) for x in disk_rows_all)}")
        else:
            print("No Disk rows to append.")

        if net_rows_all:
            append_rows_to_excel(pd.concat(net_rows_all, ignore_index=True), NETWORK_XLSX, NETWORK_COLS)
            print(f"Appended Network rows: {sum(len(x) for x in net_rows_all)}")
        else:
            print("No Network rows to append.")

        if mem_rows_all:
            append_rows_to_excel(pd.concat(mem_rows_all, ignore_index=True), MEMORY_XLSX, MEMORY_COLS)
            print(f"Appended Memory rows: {sum(len(x) for x in mem_rows_all)}")
        else:
            print("No Memory rows to append.")

    print("\nAll families processed.")

if __name__ == "__main__":
    main()
