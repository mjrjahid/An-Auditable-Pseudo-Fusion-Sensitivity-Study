#!/usr/bin/env python3
"""
mb_family_shas_2023_2025.py
Fetch SHA-256s from MalwareBazaar for given families (2023–2025) and write <Family>.txt.

Requirements:
  pip install requests

Auth:
  export MB_API_KEY=YOUR_MALWAREBAZAAR_KEY   (Windows: set MB_API_KEY=...)
  Get a free key from the abuse.ch portal; every request must include `Auth-Key`. 
"""
#8c036ca9a2aa90595b5ec6c567778ac8230720061cf7e5b0
import os
import requests
import time
from pathlib import Path
from datetime import datetime, timezone

MB_API = "https://mb-api.abuse.ch/api/v1/"
TIMEOUT = 30
BACKOFF = 1.5

MB_API_KEY = os.getenv("MB_API_KEY", "8c036ca9a2aa90595b5ec6c567778ac8230720061cf7e5b0").strip()
HEADERS = {
    "Auth-Key": MB_API_KEY,          # REQUIRED by MalwareBazaar API
    "User-Agent": "mb-family-harvest/1.0",
    "Accept": "application/json",
}

FAMILIES = [
    "conti", "ryuk", "wannacry", "qbot", "phobos",
    "agenttesla", "redline", "lumma", "blackcat",
    "lockbit", "clop", "revil","a310logger","AgentTesla","AsyncRAT","Kovter","DonutLoader","Chaos"
]

ALIASES = {
    "qbot": {"qbot", "qakbot", "qakbot_trojan", "qakbot-botnet", "qbot_trojan"},
    "agenttesla": {"agenttesla", "agent.tesla", "agent_tesla"},
    "redline": {"redline", "redline_stealer", "redline-stealer", "redlinestealer"},
    "lumma": {"lumma", "lummac2", "lumma_stealer", "lumma-stealer", "lummastealer"},
    "blackcat": {"blackcat", "alphv", "alphv_blackcat"},
    "lockbit": {"lockbit", "lockbit2", "lockbit3"},
    "clop": {"clop", "c.lop"},
    "revil": {"revil", "sodinokibi"},
    "conti": {"conti"},
    "ryuk": {"ryuk"},
    "wannacry": {"wannacry", "wcry"},
    "phobos": {"phobos"},
}

START = datetime(2020, 1, 1, tzinfo=timezone.utc)
END   = datetime(2025, 12, 31, 23, 59, 59, tzinfo=timezone.utc)

OUT_DIR = Path("mb_shas_2020_2025")
OUT_DIR.mkdir(exist_ok=True)

def _post(form: dict):
    """POST helper with Auth-Key header, backoff, and defensive JSON handling."""
    tries = 0
    while True:
        r = requests.post(MB_API, headers=HEADERS, data=form, timeout=TIMEOUT)
        if r.status_code == 429 and tries < 5:
            delay = BACKOFF * (tries + 1)
            print(f"429 rate limited; sleeping {delay:.1f}s…")
            time.sleep(delay); tries += 1
            continue
        if r.status_code == 401:
            print("401 Unauthorized — is MB_API_KEY set and correct?")
            return None
        if r.status_code >= 400:
            print(f"HTTP {r.status_code} for {form.get('query')} -> {r.text[:200]}")
            return None
        try:
            return r.json()
        except Exception:
            print("Non-JSON response.")
            return None

def parse_first_seen(ts: str):
    if not ts: return None
    ts = ts.strip().replace(" UTC","")
    try:
        dt = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None

def within_window(row: dict) -> bool:
    dt = parse_first_seen(row.get("first_seen") or row.get("firstseen") or "")
    if not dt: return False
    return START <= dt <= END

def normalize_rows(js) -> list:
    if not js or not isinstance(js, dict): return []
    data = js.get("data"); 
    if not isinstance(data, list): return []
    out = []
    for it in data:
        if not isinstance(it, dict): continue
        sha = it.get("sha256") or it.get("sha256_hash")
        if not sha: continue
        out.append({
            "sha256": str(sha).strip(),
            "first_seen": it.get("first_seen") or it.get("firstseen") or "",
            "signature": it.get("signature"),
            "tags": it.get("tags") if isinstance(it.get("tags"), list) else [],
        })
    return out

def query_tag(tag: str) -> list:
    form = {
        "query": "get_taginfo",
        "tag": tag,
        "limit": 900
    }
    return normalize_rows(_post(form) or {})

def variants_for_family(fam: str) -> set:
    base = {fam, fam.lower(), fam.replace(" ", ""), fam.replace(" ", "_")}
    if fam.lower() in ALIASES:
        base |= set(ALIASES[fam.lower()])
    return base

def harvest_family(fam: str) -> set:
    seen = set()
    vars_ = variants_for_family(fam)
    print(f"\n=== {fam} ===")
    print(f"  variants: {', '.join(sorted(vars_))}")

    for tg in sorted(vars_):
        print(f"  [tag] {tg}")
        rows = query_tag(tg)
        kept = 0
        for r in rows:
            if len(r["sha256"]) == 64 and within_window(r):
                seen.add(r["sha256"]); kept += 1
        print(f"       + kept {kept} of {len(rows)}")
        time.sleep(0.2)

    print(f"  → total unique for {fam}: {len(seen)}")
    return seen

def write_family_txt(fam: str, shas: set):
    out = OUT_DIR / f"{fam}.txt"
    lines = ["sha256"] + sorted(shas)
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {len(shas)} hashes → {out}")

def main():
    if not MB_API_KEY:
        raise SystemExit("Set MB_API_KEY environment variable (MalwareBazaar Auth-Key).")
    print(f"Date window: {START:%Y-%m-%d} to {END:%Y-%m-%d} (UTC)")

    grand = 0
    for fam in FAMILIES:
        shas = harvest_family(fam)
        write_family_txt(fam, shas)
        grand += len(shas)
    print(f"\nDone. Total hashes across families: {grand}")

if __name__ == "__main__":
    main()
